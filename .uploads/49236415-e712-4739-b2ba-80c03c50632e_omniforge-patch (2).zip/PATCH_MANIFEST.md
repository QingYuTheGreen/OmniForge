# OmniForge 增量包说明（PATCH）

- 基线 commit：`265b4c6`（v0.2.1，稳定基线）
- 本包 = 基线之后全部改动，直接覆盖到基线工程根目录即可

## 用法

1. 解压本包，得到 `file_converter/` 目录
2. 按原路径覆盖到基线工程根目录（覆盖，不是删除；基线有、本包没有的文件保持）
3. `flutter clean && flutter pub get`

## 本轮（v0.4.0）重点：鸿蒙砍除「接收外部分享」自建通道

### 决策
鸿蒙端不再支持「别的 App 分享文件给 OmniForge / 用其他应用打开唤起 OmniForge」。
理由：
- CPF 官方 `fluttertpc_receive_sharing_intent` 明确不做「复制到缓存」，Flutter 拿到的临时 URI 没法读写，官方不修复
- 自建通道需要维护临时 URI 拷贝、权限回收、缓存清理，坑多
- 分享输入只是扩展能力，核心是用户在 App 内主动选文件

### 删除清单
- `ohos/entry/src/main/ets/plugins/OmniForgeChannel.ets`（整个文件 + 目录）
- `lib/utils/ohos_platform.dart`（整个文件）
- `EntryAbility.ets`：删掉 onCreate/onNewWant/通道注册，回到默认 FlutterAbility
- `module.json5`：删掉 `sendData` / `viewData` 两个 skill，只留 home launcher
- `main.dart`：删掉 `_initOhosIncoming`、ohos 分支、ohos_platform 导入、dart:io 导入

### 鸿蒙保留的能力（全部走官方 CPF 适配插件）
- 选文件 → file_picker（CPF git 分支）
- 分享出去 → share_plus v10.x（CPF git 分支）
- 用其他应用打开 → open_filex（CPF git 分支）
- 输出目录 → path_provider（CPF git 分支）

### 安卓 / iOS 不受影响
- 接收分享仍走 `receive_sharing_intent ^1.8.1`（pub 版），`AndroidManifest.xml` 的 SEND/SEND_MULTIPLE/VIEW intent-filter 原样保留
- iOS 的 Info.plist 文件接收配置原样保留

### pubspec 改动（4 个 git 依赖）
| 插件 | 原 pub 版 | git ref |
|---|---|---|
| path_provider | ^2.1.2 | `flutter_packages` monorepo，path `packages/path_provider/path_provider`，ref `br_path_provider-v2.1.5_ohos` |
| file_picker | ^8.0.0 | `fluttertpc_file_picker`，ref `br_v8.0.7_ohos` |
| open_filex | ^4.4.0 | `fluttertpc_open_filex`，ref `br_v4.5.0_ohos` |
| share_plus | ^8.0.0 | `flutter_plus_plugins` monorepo，path `packages/share_plus/share_plus`，ref `br_share_plus-v10.1.1_ohos` |

share_plus API 已迁移到 v10.x：
```dart
await SharePlus.instance.share(
  ShareParams(files: [SharedFile(path: path)], text: file.name),
);
```

## 注意
- 本地无 Flutter SDK，git 分支/path 已 `git ls-remote` 实查存在；**push 后以 CI 为准**
- 鸿蒙侧只剩 4 个官方插件 + 入口，没有任何自建 MethodChannel，编译链路更简单
