# OmniForge 增量补丁 · 基于 commit a7b5984 之后的状态

本补丁以你仓库 **当前 main（9/9 全绿那版）** 为基线，只改功能代码和 Android 原生文件，
**没有改动** `.github/workflows/build.yml`、`ios/Podfile`、`macos/Podfile`、`ohos/*`、`analysis_options.yaml`、`pubspec.lock`。

## 一、覆盖（解压后直接覆盖到项目根目录）

| 文件 | 改了什么 |
|---|---|
| `pubspec.yaml` | 新增 4 个依赖：dynamic_color、device_info_plus、permission_handler、receive_sharing_intent |
| `lib/main.dart` | 动态取色（DynamicColorBuilder）+ 安卓版本检测 + 接收分享文件 |
| `lib/utils/output_paths.dart` | **新增**，跨平台输出目录 |
| `lib/features/home/home_provider.dart` | 去 demo 假数据、类型→格式级联数据、真实输出路径、addExternalFile |
| `lib/features/home/home_page.dart` | Tab 切换动画、分享/打开/详细信息接线、长文件名按设置显示 |
| `lib/features/home/config_page.dart` | 输入/输出类型→格式级联、未选类型禁用格式行、扩展名自动识别 |
| `lib/features/settings/settings_provider.dart` | 新增文件名显示 / 桌面图标枚举 |
| `lib/features/settings/settings_page.dart` | 外观/文件名/主题色/桌面图标/输出目录 + 存储权限申请 |
| `android/app/build.gradle` | namespace + applicationId → `com.file.omniforge.app` |
| `android/app/src/main/AndroidManifest.xml` | label=OmniForge、存储权限、VIEW/SEND/SEND_MULTIPLE 三个 intent-filter |
| `android/app/src/main/kotlin/com/file/omniforge/app/MainActivity.kt` | **新增路径**（新包名） |

## 二、必须删除的旧文件（不删会有重复类 / 编译失败）

```
lib/app.dart
lib/features/home/convert_tab.dart
lib/features/home/files_tab.dart
lib/features/home/result_dialog.dart
android/app/src/main/kotlin/com/omniforge/app/omniforge/MainActivity.kt
```

最后一个是旧包名的 MainActivity，新包名目录建好后**必须删**，否则 Kotlin 会有两个入口类。

## 三、应用后执行

```bash
# 1) 删除上面 5 个文件
# 2) 拉依赖（会自动更新 pubspec.lock，无需手动改）
flutter pub get
# 3) 构建
flutter build apk --release --split-per-abi
```

## 四、已知风险（应用前请知悉）

1. **鸿蒙 OHOS 可能挂**：`dynamic_color` / `device_info_plus` / `permission_handler` / `receive_sharing_intent` 都不含 ohos 实现。
   如果 ohos job 报插件不支持，处理顺序是：先删 `receive_sharing_intent`（它只影响分享接收），再删 `permission_handler`（改成直接写应用私有目录），最后才动 `dynamic_color`。
2. **iOS 分享接收未配置**：`receive_sharing_intent` 在 iOS 需要 Info.plist 加 `CFBundleDocumentTypes` + App Group（如果要 share extension）。
   当前不改 iOS 原生文件，iOS 能正常编译，只是「从别的 App 分享文件进来」这个功能在 iOS 上不生效。
3. **pubspec.lock 未同步**：故意不改，交给 CI/本地 `flutter pub get` 重新解析，避免手写 lock 造成依赖漂移。
4. 转换仍是模拟进度，真实引擎（FFmpeg）按你说的「先不完善转换」暂未接入；但输出文件会真实创建在输出目录里，分享/打开/详细信息可用。
