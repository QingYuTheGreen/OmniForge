# OmniForge 增量补丁清单（PATCH_MANIFEST）

基线：仓库 `QingYuTheGreen/OmniForge` main（v0.2.1 已修复导入路径与 BoxShadow 参数名）。
本补丁只覆盖功能代码和 Android 原生文件，**不改动** build.yml、ios/macos Podfile、ohos/*、analysis_options.yaml。

## 一、覆盖 / 新增的文件

| 文件 | 说明 |
|---|---|
| `pubspec.yaml` | 4 个依赖：dynamic_color、device_info_plus、permission_handler、receive_sharing_intent |
| `lib/main.dart` | 动态取色 + 版本检测 + 分享接收 |
| `lib/utils/output_paths.dart` | 新增，跨平台输出目录 |
| `lib/features/home/home_provider.dart` | 去 mock、级联映射、真实输出路径、addExternalFile |
| `lib/features/home/home_page.dart` | Tab 动画、分享/打开/详情、长文件名 |
| `lib/features/home/config_page.dart` | 类型→格式级联、自动识别扩展名 |
| `lib/features/settings/settings_provider.dart` | 文件名显示 / 桌面图标枚举 |
| `lib/features/settings/settings_page.dart` | 卡片式设置页 + 输出目录 + 权限入口 |
| `android/app/build.gradle` | 包名 `com.file.omniforge.app`；**compileSdk 显式设为 37** |
| `android/app/src/main/AndroidManifest.xml` | label=OmniForge、存储权限、3 个 intent-filter |
| `android/app/src/main/kotlin/com/file/omniforge/app/MainActivity.kt` | 新包名入口 |

## 二、必须删除的旧文件

```
lib/app.dart
lib/features/home/convert_tab.dart
lib/features/home/files_tab.dart
lib/features/home/result_dialog.dart
android/app/src/main/kotlin/com/omniforge/app/omniforge/MainActivity.kt
```

## 三、应用后执行

```bash
flutter pub get
flutter build apk --release --split-per-abi
```

## 四、已踩过的坑（不要再犯）

1. settings_page.dart 在 `lib/features/settings/` 下，导入 lib/utils 必须是 `../../utils/output_paths.dart`，`../utils/` 少一层。
2. `BoxShadow` 的参数是 `spreadRadius`，**没有** `spread` 这个命名参数。
3. `receive_sharing_intent` 要求 compileSdk 37，Flutter 3.47.9 默认 compileSdk 是 36，必须显式 `compileSdk = 37`；CI 缺该 platform 时 AGP 会自动通过 sdkmanager 下载。
4. 4 个插件都没有 ohos 实现，OHOS job 若失败，降级顺序：receive_sharing_intent → permission_handler → dynamic_color。
